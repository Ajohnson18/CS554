import { useEffect, useState } from "react";
import { useQuery } from "@apollo/client";
import ImageTile from "./ImageTile";
import { CircularProgress } from "@material-ui/core";
import query from "./queries";
import Nav from "./Nav";

const Bin = () => {
  const [pageData, setPageData] = useState([]);
  const { loading, error, data } = useQuery(query.GET_BIN);
  const [slength, setLength] = useState(0);

  useEffect(() => {
    if (data) setPageData(data.binnedImages);
    if (data) setLength(data.binnedImages.length);
  }, [data]);

  if (error) {
    return <h1>{error}</h1>;
  } else {
    return (
      <div>
        <Nav selected={1} />
        {loading ? (
          <CircularProgress />
        ) : (
          pageData.map((item, index) => {
            return <ImageTile inBin={true} key={index} data2={item} />;
          })
        )}
        {slength === 0 ? <p>No Binned Images</p> : ""}
      </div>
    );
  }
};

export default Bin;
