import { useMutation } from "@apollo/client";
import { useHistory } from "react-router-dom";
import { Input, Button } from "@material-ui/core";
import { useState } from "react";
import Nav from "./Nav";
import query from "./queries";

function NewPost() {
  const history = useHistory();
  const [url, setUrl] = useState("");
  const [desc, setDesc] = useState("");
  const [name, setName] = useState("");
  const [uploadToServer] = useMutation(query.UPLOAD_POST);

  const handleUrl = (event) => {
    setUrl(event.target.value);
  };

  const handleDesc = (event) => {
    setDesc(event.target.value);
  };

  const handleName = (event) => {
    setName(event.target.value);
  };

  function submit() {
    uploadToServer({
      variables: {
        url: url,
        posterName: name,
        description: desc,
      },
    });

    history.push("/my-posts");
  }

  return (
    <div>
      <Nav />
      <h1>Add a new bin post!</h1>
      <label for="url">IMG URL: </label>
      <Input onChange={handleUrl} id="url" placeholder="Image URL" />
      <br /> <br />
      <label for="desc">Description: </label>
      <Input
        onChange={handleDesc}
        id="desc"
        placeholder="Description"
      /> <br /> <br />
      <label for="name">Poster Name</label>
      <Input
        id="name"
        onChange={handleName}
        placeholder="Poster Name"
      /> <br /> <br />
      <Button onClick={submit} variant="contained" color="primary">
        Submit
      </Button>
    </div>
  );
}

export default NewPost;
