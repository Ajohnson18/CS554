import React, { useEffect, useState } from "react";
import { useQuery, useMutation } from "@apollo/client";
import query from "./queries";
import "./../App.css";
import { CircularProgress, LinearProgress } from "@material-ui/core";

const PostTile = ({ data2, inBin, userPosted }) => {
  const [removePost] = useMutation(query.REMOVE_POST);
  const [loading2, setLoading] = useState(false);
  const { loading, error, data } = useQuery(query.GET_USER_FEED);
  const [mainId, setmainId] = useState("");
  const [deletei, setDelete] = useState(false);

  useEffect(() => {
    let idsTemp = [];
    if (!data) return;
    for (let i = 0; i < data.userPostedImages.length; i++) {
      if (data.userPostedImages[i].url === data2.url) {
        setmainId(data.userPostedImages[i].id);
      }
      idsTemp.push(data.userPostedImages[i].url);
    }
  }, [data]);

  async function remove() {
    setLoading(true);

    await removePost({ variables: { id: mainId } });
    setDelete(true);

    setLoading(false);
  }

  if (deletei) return <p></p>;
  if (error) {
    return <h1>{error}</h1>;
  } else if (data) {
    return (
      <div className="image-tile">
        <p>{data2.description}</p>
        <p>
          <i>{data2.posterName}</i>
        </p>
        <img src={data2.url} alt="image" />
        {loading2 ? (
          <CircularProgress />
        ) : (
          <button onClick={remove}>delete</button>
        )}
      </div>
    );
  } else {
    return <LinearProgress />;
  }
};

export default PostTile;
