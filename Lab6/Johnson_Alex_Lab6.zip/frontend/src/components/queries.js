import { gql } from "@apollo/client";

const GET_BIN = gql`
  query {
    binnedImages {
      id
      url
      posterName
      description
      userPosted
    }
  }
`;

const GET_USER_FEED = gql`
  query {
    userPostedImages {
      id
      url
      posterName
      description
      binned
    }
  }
`;

const GET_FEED = gql`
  query unsplash($pageNum: Int!) {
    unsplashImages(pageNum: $pageNum) {
      url
      posterName
      description
      id
    }
  }
`;

const REMOVE_FROM_BIN = gql`
  mutation remove_bin($id: ID!) {
    updateImage(id: $id, binned: false) {
      url
      posterName
      description
    }
  }
`;

const ADD_TO_BIN = gql`
  mutation addToBin($id: ID!, $binned: Boolean!, $userPosted: Boolean!) {
    updateImage(id: $id, binned: $binned, userPosted: $userPosted) {
      url
      description
      posterName
      id
    }
  }
`;

const REMOVE_POST = gql`
  mutation delete($id: ID!) {
    deleteImage(id: $id) {
      url
      posterName
      description
    }
  }
`;

const UPLOAD_POST = gql`
  mutation upload($url: String!, $description: String, $posterName: String) {
    uploadImage(url: $url, description: $description, posterName: $posterName) {
      id
      url
      posterName
      description
    }
  }
`;

export default {
  GET_BIN,
  GET_USER_FEED,
  GET_FEED,
  REMOVE_FROM_BIN,
  ADD_TO_BIN,
  REMOVE_POST,
  UPLOAD_POST,
};
