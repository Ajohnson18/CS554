import { useEffect, useState } from "react";
import { useQuery } from "@apollo/client";
import ImageTile from "./ImageTile";
import { CircularProgress, Button } from "@material-ui/core";
import query from "./queries";
import Nav from "./Nav";
import { useHistory } from "react-router-dom";
import PostTile from "./PostTile";

const Posts = () => {
  const history = useHistory();
  const [pageData, setPageData] = useState([]);
  const { loading, error, data } = useQuery(query.GET_USER_FEED);
  const [slength, setLength] = useState(0);

  function addPost() {
    history.push("/new-post");
  }

  useEffect(() => {
    if (data) setPageData(data.userPostedImages);
    if (data) setLength(data.userPostedImages.length);
  }, [data]);

  if (error) {
    return <h1>{error}</h1>;
  } else {
    return (
      <div>
        <Nav selected={1} />
        <Button onClick={addPost} variant="contained" color="primary">
          Add Post
        </Button>
        {loading ? (
          <CircularProgress />
        ) : (
          pageData.map((item, index) => {
            return (
              <PostTile
                userPosted={true}
                inBin={true}
                key={index}
                data2={item}
              />
            );
          })
        )}
        {slength === 0 ? <p>No Posted Images</p> : ""}
      </div>
    );
  }
};

export default Posts;
