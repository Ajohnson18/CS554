import React, { useEffect, useState } from "react";
import { useQuery, useMutation } from "@apollo/client";
import query from "./queries";
import "./../App.css";
import { CircularProgress, LinearProgress } from "@material-ui/core";

const ImageTile = ({ data2, inBin, userPosted }) => {
  const [addToBin] = useMutation(query.ADD_TO_BIN);
  const [uploadToServer] = useMutation(query.UPLOAD_POST);
  const [removePost] = useMutation(query.REMOVE_POST);
  const [removeFromBin] = useMutation(query.REMOVE_FROM_BIN);
  const [loading2, setLoading] = useState(false);
  const [ids, setids] = useState([]);
  const { loading, error, data } = useQuery(query.GET_BIN);
  const [mainId, setmainId] = useState("");
  const [deletei, setDelete] = useState(false);

  useEffect(() => {
    let idsTemp = [];
    if (!data) return;
    for (let i = 0; i < data.binnedImages.length; i++) {
      if (data.binnedImages[i].url === data2.url) {
        setmainId(data.binnedImages[i].id);
      }
      idsTemp.push(data.binnedImages[i].url);
    }
    setids(idsTemp);
  }, [data]);

  async function bin() {
    setLoading(true);

    let id = await uploadToServer({
      variables: {
        url: data2.url,
        posterName: data2.posterName,
        description: data2.description,
      },
    });

    addToBin({
      variables: {
        id: id.data.uploadImage.id,
        userPosted: false,
        binned: true,
      },
    });

    setmainId(id.data.uploadImage.id);

    ids.push(data2.url);
    setids(ids);

    setLoading(false);
  }

  async function unBin() {
    setLoading(true);

    removeFromBin({ variables: { id: mainId } });

    let i = ids.indexOf(mainId);
    ids.splice(i, 1);
    setids(ids);

    if (inBin) {
      setDelete(true);
    }

    setLoading(false);
  }

  async function remove() {
    setLoading(true);

    await removePost({ variables: { id: mainId } });
    setDelete(true);

    setLoading(false);
  }

  if (deletei) return <p></p>;
  if (error) {
    return <h1>{error}</h1>;
  } else if (data) {
    return (
      <div className="image-tile">
        <p>{data2.description}</p>
        <p>
          <i>{data2.posterName}</i>
        </p>
        <img src={data2.url} alt="image" />
        {userPosted ? (
          loading2 ? (
            <CircularProgress />
          ) : (
            <button onClick={remove}>delete</button>
          )
        ) : loading2 ? (
          <CircularProgress />
        ) : ids.includes(data2.url) ? (
          <button onClick={unBin}>remove from bin</button>
        ) : (
          <button onClick={bin}>add to bin</button>
        )}
      </div>
    );
  } else {
    return <LinearProgress />;
  }
};

export default ImageTile;
