import { useEffect, useState } from "react";
import { useQuery } from "@apollo/client";
import ImageTile from "./ImageTile";
import { Button, CircularProgress } from "@material-ui/core";
import query from "./queries";
import Nav from "./Nav";

const Feed = () => {
  const [pageNum, setPageNum] = useState(0);
  const [pageData, setPageData] = useState([]);
  const { loading, error, data } = useQuery(query.GET_FEED, {
    variables: { pageNum: pageNum },
  });

  function getMore() {
    setPageNum(pageNum + 1);
  }

  useEffect(() => {
    if (data && data.unsplashImages.length === 0) {
      setPageNum(0);
      return;
    }
    if (data) setPageData(data.unsplashImages);
  }, [data]);

  if (error) {
    return <h1>{error}</h1>;
  } else {
    return (
      <div>
        <Nav selected={0} />
        {loading ? (
          <CircularProgress />
        ) : (
          pageData.map((item, index) => {
            return <ImageTile key={index} data2={item} />;
          })
        )}
        <br />
        <Button
          style={{ margin: 20 }}
          onClick={getMore}
          variant="contained"
          color="secondary"
        >
          get more
        </Button>
      </div>
    );
  }
};

export default Feed;
