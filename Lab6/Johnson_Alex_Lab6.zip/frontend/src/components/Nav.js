import DeleteIcon from "@material-ui/icons/Delete";
import "./../App.css";

const Nav = ({ selected }) => {
  return (
    <div className="nav">
      <div className="head">
        <span>
          <DeleteIcon fontSize="small" />
        </span>
        <p>Binterest</p>
      </div>
      <ul>
        <li>
          <a href="/my-bin" className={selected === 1 ? "selected" : ""}>
            my bin
          </a>
        </li>
        <li>|</li>
        <li>
          <a href="/" className={selected === 0 ? "selected" : ""}>
            images
          </a>
        </li>
        <li>|</li>
        <li>
          <a href="/my-posts" className={selected === 2 ? "selected" : ""}>
            my posts
          </a>
        </li>
      </ul>
    </div>
  );
};

export default Nav;
