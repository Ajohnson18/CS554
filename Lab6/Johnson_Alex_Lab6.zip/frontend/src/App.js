import "./App.css";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Feed from "./components/Feed";
import NewPost from "./components/NewPost";
import {
  ApolloClient,
  HttpLink,
  InMemoryCache,
  ApolloProvider,
} from "@apollo/client";
import Bin from "./components/Bin";
import Posts from "./components/Posts";

const client = new ApolloClient({
  cache: new InMemoryCache(),
  link: new HttpLink({
    uri: "http://localhost:4000",
  }),
});

function App() {
  return (
    <ApolloProvider client={client}>
      <Router>
        <div>
          <Route exact path="/">
            <Feed />
          </Route>
          <Route exact path="/my-bin">
            <Bin />
          </Route>
          <Route exact path="/my-posts">
            <Posts />
          </Route>
          <Route exact path="/new-post" component={NewPost} />
        </div>
      </Router>
    </ApolloProvider>
  );
}

export default App;
