const movieData = require("./movies");
const commentData = require("./comments");

module.exports = {
  movies: movieData,
  comments: commentData,
};
