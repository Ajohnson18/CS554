const initalState = [];

const dataReducer = (state = initalState, action) => {
  const { type, payload } = action;

  switch (type) {
    case "SET_DATA":
      return payload.data.results;
    default:
      return state;
  }
};

export default dataReducer;
