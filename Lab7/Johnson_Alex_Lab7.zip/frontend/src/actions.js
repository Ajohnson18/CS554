const setData = (data) => ({
  type: "SET_DATA",
  payload: {
    data: data,
  },
});

module.exports = {
  setData,
};
