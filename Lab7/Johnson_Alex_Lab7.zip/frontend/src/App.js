import "./App.css";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Home from "./components/Home";
import Characters from "./components/Characters";
import Character from "./components/Character";
import Series from "./components/Series";
import Serie from "./components/Serie";
import Comics from "./components/Comics";
import Comic from "./components/Comic";
import {
  ApolloClient,
  HttpLink,
  InMemoryCache,
  ApolloProvider,
} from "@apollo/client";

const client = new ApolloClient({
  cache: new InMemoryCache(),
  link: new HttpLink({
    uri: "http://localhost:4000",
  }),
});

function App() {
  return (
    <ApolloProvider client={client}>
      <Router>
        <div className="App">
          <header className="App-header">
            <h1 className="App-title">Welcome to Marvel API</h1>
            <Link className="characterslink" to="/characters/page/0">
              Characters
            </Link>
            <p></p>
            <Link className="comicslink" to="/comics/page/0">
              Comics
            </Link>
            <p></p>
            <Link className="serieslink" to="/series/page/0">
              Series
            </Link>
            <hr />
          </header>
          <div className="App-body">
            <Route exact path="/" component={Home} />
            <Route exact path="/characters/page/:page" component={Characters} />
            <Route exact path="/characters/:id" component={Character} />
            <Route exact path="/comics/page/:page" component={Comics} />
            <Route exact path="/comics/:id" component={Comic} />
            <Route exact path="/series/page/:page" component={Series} />
            <Route exact path="/series/:id" component={Serie} />
          </div>
        </div>
      </Router>
    </ApolloProvider>
  );
}

export default App;
