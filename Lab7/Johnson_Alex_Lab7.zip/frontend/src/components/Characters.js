import { useEffect } from "react";
import { useQuery } from "@apollo/client";
import { useDispatch, useSelector } from "react-redux";
import query from "./queries";
import actions from "../actions";

const Characters = (props) => {
  const dispatch = useDispatch();
  const page = props.match.params.page;
  const { loading, error, data } = useQuery(query.GET_CHARACTERS, {
    variables: { pageNum: parseInt(props.match.params.page) },
  });
  const pageData = useSelector((state) => state.data);

  useEffect(() => {
    if (data) {
      let res = JSON.parse(data.getCharactersList.data);
      dispatch(actions.setData(res));
    }
  }, [data, props.match.params.page, dispatch]);

  return (
    <div>
      <h2>Characters</h2>
      <p>Page {page}</p>
      {error ? (
        <h1>404 not found</h1>
      ) : pageData ? (
        <div>
          {pageData.length === 0 ? (
            <h2>404 not found</h2>
          ) : page === 0 ? null : (
            <a href={"/characters/page/" + (parseInt(page) - 1)}>Prev</a>
          )}{" "}
          {pageData.length > 0 ? (
            <a href={"/characters/page/" + (parseInt(page) + 1)}>Next</a>
          ) : (
            <p></p>
          )}
          <br />
          <hr />
          <br />
          {loading ? (
            <p>Loading...</p>
          ) : (
            pageData.map((item, index) => (
              <div key={index}>
                <a href={"/characters/" + item.id} key={index}>
                  {item.name}
                </a>
                <br />
                <br />
              </div>
            ))
          )}
        </div>
      ) : (
        <p></p>
      )}
    </div>
  );
};

export default Characters;
