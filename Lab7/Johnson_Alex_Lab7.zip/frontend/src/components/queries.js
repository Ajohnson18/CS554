import { gql } from "@apollo/client";

const GET_CHARACTERS = gql`
  query getCharacters($pageNum: Int!) {
    getCharactersList(pageNum: $pageNum) {
      data
    }
  }
`;

const GET_CHARACTER = gql`
  query character($id: String!) {
    getCharacter(id: $id) {
      data
    }
  }
`;

const GET_COMICS = gql`
  query getComics($pageNum: Int!) {
    getComicsList(pageNum: $pageNum) {
      data
    }
  }
`;

const GET_COMIC = gql`
  query getComic($id: String!) {
    getComic(id: $id) {
      data
    }
  }
`;

const GET_SERIES = gql`
  query getSeries($pageNum: Int!) {
    getSeriesList(pageNum: $pageNum) {
      data
    }
  }
`;

const GET_SERIE = gql`
  query getSerie($id: String!) {
    getSerie(id: $id) {
      data
    }
  }
`;

export default {
  GET_CHARACTERS,
  GET_CHARACTER,
  GET_COMICS,
  GET_COMIC,
  GET_SERIES,
  GET_SERIE,
};
