function Home() {
  return (
    <p>
      This app is created to display information about Marvel information. To
      retrieve the information this app uses the Marvel API which pulls data
      with HTTP requests and is used to display information on this page.
    </p>
  );
}

export default Home;
