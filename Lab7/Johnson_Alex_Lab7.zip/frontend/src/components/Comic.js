import { useEffect } from "react";
import { useQuery } from "@apollo/client";
import { useDispatch, useSelector } from "react-redux";
import query from "./queries";
import actions from "../actions";

const Comic = (props) => {
  const dispatch = useDispatch();
  const { loading, error, data } = useQuery(query.GET_COMIC, {
    variables: { id: props.match.params.id },
  });
  const pageDataFull = useSelector((state) => state.data);

  useEffect(() => {
    if (data) {
      let res = JSON.parse(data.getComic.data);
      dispatch(actions.setData(res));
    }
  }, [data, props.match.params.id, dispatch]);

  let pageData = {};
  if (pageDataFull) {
    pageData = pageDataFull[0];
  }

  return (
    <div>
      {error ? (
        <h2>404 not found</h2>
      ) : (
        <div>
          <p>{loading ? "Loading..." : null}</p>
          {pageData !== undefined ? (
            <div>
              <h2>Title: {pageData.title}</h2>
              <p>Description: {pageData.description}</p>
              <p>Stories:</p>
              <ul>
                {pageData.stories ? (
                  pageData.stories.items.map((item, index) => {
                    return <li key={index}>{item.name}</li>;
                  })
                ) : (
                  <li></li>
                )}
              </ul>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
};

export default Comic;
