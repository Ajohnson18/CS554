import { useEffect } from "react";
import { useQuery } from "@apollo/client";
import { useDispatch, useSelector } from "react-redux";
import query from "./queries";
import actions from "../actions";

const Character = (props) => {
  const dispatch = useDispatch();
  const { loading, error, data } = useQuery(query.GET_CHARACTER, {
    variables: { id: props.match.params.id },
  });
  const pageDataFull = useSelector((state) => state.data);

  useEffect(() => {
    if (data) {
      let res = JSON.parse(data.getCharacter.data);
      dispatch(actions.setData(res));
    }
  }, [data, props.match.params.id, dispatch]);

  let pageData = {};
  if (pageDataFull) {
    pageData = pageDataFull[0];
  }

  return (
    <div>
      {error ? (
        <h2>404 not found</h2>
      ) : loading ? (
        <p>Loading...</p>
      ) : pageData !== undefined ? (
        <div>
          <h2>Name: {pageData.name}</h2>
          <p>Description: {pageData.description}</p>
          <p>Comics:</p>
          <ul>
            {pageData.comics ? (
              pageData.comics.items.map((item, index) => {
                return <li key={index}>{item.name}</li>;
              })
            ) : (
              <li></li>
            )}
          </ul>
          <p>Stories:</p>
          <ul>
            {pageData.stories ? (
              pageData.stories.items.map((item, index) => {
                return <li key={index}>{item.name}</li>;
              })
            ) : (
              <li></li>
            )}
          </ul>
          <p>Series:</p>
          <ul>
            {pageData.series ? (
              pageData.series.items.map((item, index) => {
                return <li key={index}>{item.name}</li>;
              })
            ) : (
              <li></li>
            )}
          </ul>
          {pageData.urls ? (
            <a href={pageData.urls[0].url}>Learn More</a>
          ) : (
            <p></p>
          )}
        </div>
      ) : null}
    </div>
  );
};

export default Character;
