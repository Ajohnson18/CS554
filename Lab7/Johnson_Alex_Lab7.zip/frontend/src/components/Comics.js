import { useEffect } from "react";
import { useQuery } from "@apollo/client";
import { useDispatch, useSelector } from "react-redux";
import query from "./queries";
import actions from "../actions";

const Comics = (props) => {
  const dispatch = useDispatch();
  const page = props.match.params.page;
  const { loading, error, data } = useQuery(query.GET_COMICS, {
    variables: { pageNum: parseInt(page) },
  });
  const pageData = useSelector((state) => state.data);

  useEffect(() => {
    if (data) {
      let res = JSON.parse(data.getComicsList.data);
      dispatch(actions.setData(res));
    }
  }, [data, props.match.params.page, dispatch]);

  return (
    <div>
      <h2>Comics</h2>
      <p>Page {page}</p>
      {error ? (
        <h1>404 not found</h1>
      ) : pageData.length === 0 ? (
        <h2>404 none found</h2>
      ) : (
        <p></p>
      )}
      {page === 0 ? null : (
        <a href={"/comics/page/" + (parseInt(page) - 1)}>Prev</a>
      )}{" "}
      {pageData.length > 0 ? (
        <a href={"/comics/page/" + (parseInt(page) + 1)}>Next</a>
      ) : (
        <p></p>
      )}
      <br />
      <hr />
      <br />
      {loading ? (
        <p>Loading...</p>
      ) : (
        pageData.map((item, index) => (
          <div key={index}>
            <a href={"/comics/" + item.id} key={index}>
              {item.title}
            </a>
            <br />
            <br />
          </div>
        ))
      )}
    </div>
  );
};

export default Comics;
